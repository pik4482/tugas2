<?php
$host     = "localhost";    // Nama host
$username = "root";         // Username database
$password = "";   // Password database
$database = "ams_native.sql";   // Nama database
